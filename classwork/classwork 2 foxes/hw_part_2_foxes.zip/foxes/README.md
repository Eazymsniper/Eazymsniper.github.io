Foxes!
========

Colors & Fonts
--------------

We are using the following colors and fonts on this page:

* The background color for this page is #797890
* The color for H1, H2, & li is: #2f2189
* The color for H3 is: #1b5081
* The link color is: #3c6798
* The font family for the H1 and H3 tags is: Georgia 
* Please make the H1: 40px 
* Please make the H3s: 20px
* Make the lists have no bullet points
* The font family for all p tags and li tags is: Helvetica 
* The font size for all p tags and li tags should be: 16px

Please follow the directions commented in the code (index.html). 

Completely Optional Bonus: Do something cool with the documentation [1]. Change the color or change the font in some way.
